﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PokerTournamentDirector.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "BlindStructures",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2026, 1, 20, 11, 41, 33, 555, DateTimeKind.Local).AddTicks(6247));

            migrationBuilder.UpdateData(
                table: "BlindStructures",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2026, 1, 20, 11, 41, 33, 555, DateTimeKind.Local).AddTicks(6415));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "BlindStructures",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2026, 1, 20, 11, 39, 52, 640, DateTimeKind.Local).AddTicks(1502));

            migrationBuilder.UpdateData(
                table: "BlindStructures",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2026, 1, 20, 11, 39, 52, 640, DateTimeKind.Local).AddTicks(1655));
        }
    }
}
