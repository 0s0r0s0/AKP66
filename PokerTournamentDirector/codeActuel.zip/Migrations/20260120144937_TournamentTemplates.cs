﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PokerTournamentDirector.Migrations
{
    /// <inheritdoc />
    public partial class TournamentTemplates : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "RebuysCount",
                table: "TournamentPlayers",
                newName: "RebuyCount");

            migrationBuilder.AlterColumn<int>(
                name: "RebuyPeriodMonths",
                table: "Tournaments",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "INTEGER",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "MaxRebuysPerPlayer",
                table: "Tournaments",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "INTEGER",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "AddOnAtLevel",
                table: "Tournaments",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "AddOnStack",
                table: "Tournaments",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "AllowAddOn",
                table: "Tournaments",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "AllowBounty",
                table: "Tournaments",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "AllowRebuys",
                table: "Tournaments",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<decimal>(
                name: "BountyAmount",
                table: "Tournaments",
                type: "TEXT",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "BountyType",
                table: "Tournaments",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "Currency",
                table: "Tournaments",
                type: "TEXT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Notes",
                table: "Tournaments",
                type: "TEXT",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PayoutStructureJson",
                table: "Tournaments",
                type: "TEXT",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "RakeType",
                table: "Tournaments",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "RebuyLimit",
                table: "Tournaments",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "RebuyLimitType",
                table: "Tournaments",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "RebuyMaxLevel",
                table: "Tournaments",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "RebuyStack",
                table: "Tournaments",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "RebuyUntilPlayersLeft",
                table: "Tournaments",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "TemplateId",
                table: "Tournaments",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "TournamentTemplates",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(type: "TEXT", maxLength: 150, nullable: false),
                    Description = table.Column<string>(type: "TEXT", nullable: true),
                    Type = table.Column<int>(type: "INTEGER", nullable: false),
                    Currency = table.Column<string>(type: "TEXT", nullable: false),
                    BuyIn = table.Column<decimal>(type: "TEXT", nullable: false),
                    Rake = table.Column<decimal>(type: "TEXT", nullable: false),
                    RakeType = table.Column<int>(type: "INTEGER", nullable: false),
                    BlindStructureId = table.Column<int>(type: "INTEGER", nullable: false),
                    StartingStack = table.Column<int>(type: "INTEGER", nullable: false),
                    MaxPlayers = table.Column<int>(type: "INTEGER", nullable: false),
                    SeatsPerTable = table.Column<int>(type: "INTEGER", nullable: false),
                    LateRegLevels = table.Column<int>(type: "INTEGER", nullable: false),
                    AllowRebuys = table.Column<bool>(type: "INTEGER", nullable: false),
                    RebuyAmount = table.Column<decimal>(type: "TEXT", nullable: true),
                    RebuyLimit = table.Column<int>(type: "INTEGER", nullable: true),
                    RebuyLimitType = table.Column<int>(type: "INTEGER", nullable: false),
                    RebuyMaxLevel = table.Column<int>(type: "INTEGER", nullable: true),
                    RebuyUntilPlayersLeft = table.Column<int>(type: "INTEGER", nullable: true),
                    RebuyStack = table.Column<int>(type: "INTEGER", nullable: true),
                    MaxRebuysPerPlayer = table.Column<int>(type: "INTEGER", nullable: false),
                    RebuyPeriodMonths = table.Column<int>(type: "INTEGER", nullable: false),
                    AllowAddOn = table.Column<bool>(type: "INTEGER", nullable: false),
                    AddOnAmount = table.Column<decimal>(type: "TEXT", nullable: true),
                    AddOnStack = table.Column<int>(type: "INTEGER", nullable: true),
                    AddOnAtLevel = table.Column<int>(type: "INTEGER", nullable: true),
                    AllowBounty = table.Column<bool>(type: "INTEGER", nullable: false),
                    BountyAmount = table.Column<decimal>(type: "TEXT", nullable: true),
                    BountyType = table.Column<int>(type: "INTEGER", nullable: false),
                    PayoutStructureJson = table.Column<string>(type: "TEXT", nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "TEXT", nullable: false),
                    LastModified = table.Column<DateTime>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TournamentTemplates", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TournamentTemplates_BlindStructures_BlindStructureId",
                        column: x => x.BlindStructureId,
                        principalTable: "BlindStructures",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.UpdateData(
                table: "BlindStructures",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2026, 1, 20, 15, 49, 36, 685, DateTimeKind.Local).AddTicks(8168));

            migrationBuilder.UpdateData(
                table: "BlindStructures",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2026, 1, 20, 15, 49, 36, 685, DateTimeKind.Local).AddTicks(8356));

            migrationBuilder.CreateIndex(
                name: "IX_Tournaments_TemplateId",
                table: "Tournaments",
                column: "TemplateId");

            migrationBuilder.CreateIndex(
                name: "IX_TournamentTemplates_BlindStructureId",
                table: "TournamentTemplates",
                column: "BlindStructureId");

            migrationBuilder.AddForeignKey(
                name: "FK_Tournaments_TournamentTemplates_TemplateId",
                table: "Tournaments",
                column: "TemplateId",
                principalTable: "TournamentTemplates",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Tournaments_TournamentTemplates_TemplateId",
                table: "Tournaments");

            migrationBuilder.DropTable(
                name: "TournamentTemplates");

            migrationBuilder.DropIndex(
                name: "IX_Tournaments_TemplateId",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "AddOnAtLevel",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "AddOnStack",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "AllowAddOn",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "AllowBounty",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "AllowRebuys",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "BountyAmount",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "BountyType",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "Currency",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "Notes",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "PayoutStructureJson",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "RakeType",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "RebuyLimit",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "RebuyLimitType",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "RebuyMaxLevel",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "RebuyStack",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "RebuyUntilPlayersLeft",
                table: "Tournaments");

            migrationBuilder.DropColumn(
                name: "TemplateId",
                table: "Tournaments");

            migrationBuilder.RenameColumn(
                name: "RebuyCount",
                table: "TournamentPlayers",
                newName: "RebuysCount");

            migrationBuilder.AlterColumn<int>(
                name: "RebuyPeriodMonths",
                table: "Tournaments",
                type: "INTEGER",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "INTEGER");

            migrationBuilder.AlterColumn<int>(
                name: "MaxRebuysPerPlayer",
                table: "Tournaments",
                type: "INTEGER",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "INTEGER");

            migrationBuilder.UpdateData(
                table: "BlindStructures",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2026, 1, 20, 11, 41, 33, 555, DateTimeKind.Local).AddTicks(6247));

            migrationBuilder.UpdateData(
                table: "BlindStructures",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2026, 1, 20, 11, 41, 33, 555, DateTimeKind.Local).AddTicks(6415));
        }
    }
}
