using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using PokerTournamentDirector.Models;
using PokerTournamentDirector.Services;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace PokerTournamentDirector.ViewModels
{
    public partial class EliminationViewModel : ObservableObject
    {
        private readonly TournamentService _tournamentService;
        private readonly PlayerService _playerService;
        private readonly int _tournamentId;
        private Tournament? _tournament;

        [ObservableProperty]
        private ObservableCollection<TournamentPlayer> _activePlayers = new();

        [ObservableProperty]
        private ObservableCollection<TournamentPlayer> _availableKillers = new();

        [ObservableProperty]
        private TournamentPlayer? _selectedEliminatedPlayer;

        [ObservableProperty]
        private TournamentPlayer? _selectedKillerPlayer;

        [ObservableProperty]
        private ObservableCollection<EliminationHistoryItem> _eliminationHistory = new();

        // Gestion recave
        [ObservableProperty]
        private bool _canRebuy = false;

        [ObservableProperty]
        private string _rebuyMessage = string.Empty;

        [ObservableProperty]
        private int _rebuyCount = 0;

        [ObservableProperty]
        private decimal _rebuyAmount = 0;

        [ObservableProperty]
        private bool _showRebuySection = false;

        // Stats
        [ObservableProperty]
        private int _playersRemaining = 0;

        [ObservableProperty]
        private int _totalEliminations = 0;

        [ObservableProperty]
        private decimal _currentPrizePool = 0;

        // Indicateur de fin de tournoi
        [ObservableProperty]
        private bool _isTournamentFinished = false;

        [ObservableProperty]
        private string _winnerName = string.Empty;

        // Événement pour notifier le parent que le tournoi est fini
        public event EventHandler<string>? TournamentFinished;

        public EliminationViewModel(TournamentService tournamentService, PlayerService playerService, int tournamentId)
        {
            _tournamentService = tournamentService;
            _playerService = playerService;
            _tournamentId = tournamentId;
        }

        public async Task InitializeAsync()
        {
            _tournament = await _tournamentService.GetTournamentAsync(_tournamentId);
            if (_tournament == null) return;

            RebuyAmount = _tournament.RebuyAmount ?? 0;
            ShowRebuySection = _tournament.Type == TournamentType.RebuyUnlimited ||
                              _tournament.Type == TournamentType.RebuyLimited ||
                              _tournament.Type == TournamentType.DoubleChance;

            await RefreshPlayersAsync();
            await RefreshStatsAsync();
        }

        private async Task RefreshPlayersAsync()
        {
            var players = await _tournamentService.GetActivePlayers(_tournamentId);

            ActivePlayers.Clear();
            foreach (var player in players.OrderBy(p => p.Player!.Name))
            {
                ActivePlayers.Add(player);
            }

            // Mettre à jour la liste des killers disponibles
            UpdateAvailableKillers();

            PlayersRemaining = ActivePlayers.Count;
        }

        private void UpdateAvailableKillers()
        {
            AvailableKillers.Clear();
            
            foreach (var player in ActivePlayers)
            {
                // Ne pas inclure le joueur sélectionné pour élimination
                if (SelectedEliminatedPlayer == null || player.Id != SelectedEliminatedPlayer.Id)
                {
                    AvailableKillers.Add(player);
                }
            }
        }

        private async Task RefreshStatsAsync()
        {
            if (_tournament == null) return;

            // Recharger le tournoi
            _tournament = await _tournamentService.GetTournamentAsync(_tournamentId);
            if (_tournament == null) return;

            CurrentPrizePool = await _tournamentService.CalculatePrizePoolAsync(_tournamentId);

            var allPlayers = _tournament.Players.ToList();
            TotalEliminations = allPlayers.Count(p => p.IsEliminated);
        }

        partial void OnSelectedEliminatedPlayerChanged(TournamentPlayer? value)
        {
            // Mettre à jour la liste des killers disponibles pour exclure le joueur sélectionné
            UpdateAvailableKillers();

            // Réinitialiser le killer sélectionné si c'est le même que le joueur éliminé
            if (SelectedKillerPlayer != null && value != null && SelectedKillerPlayer.Id == value.Id)
            {
                SelectedKillerPlayer = null;
            }

            if (value != null)
            {
                _ = CheckRebuyAvailabilityAsync();
            }
        }

        private async Task CheckRebuyAvailabilityAsync()
        {
            if (SelectedEliminatedPlayer == null || _tournament == null) return;

            var playerId = SelectedEliminatedPlayer.PlayerId;

            // Vérifier si le joueur peut recaver
            CanRebuy = await _playerService.CanPlayerRebuyAsync(playerId, _tournamentId);
            RebuyCount = await _playerService.GetPlayerRebuyCountAsync(playerId, _tournamentId);

            if (CanRebuy)
            {
                if (_tournament.MaxRebuysPerPlayer > 0)
                {
                    int remaining = _tournament.MaxRebuysPerPlayer - RebuyCount;
                    RebuyMessage = $"✅ Recave disponible ({remaining} restante(s))";
                }
                else
                {
                    RebuyMessage = $"✅ Recave disponible (illimitées - {RebuyCount} effectuée(s))";
                }
            }
            else
            {
                var nextDate = await _playerService.GetNextRebuyAvailableDateAsync(playerId, _tournamentId);
                if (nextDate.HasValue)
                {
                    RebuyMessage = $"❌ Limite atteinte ({RebuyCount}/{_tournament.MaxRebuysPerPlayer})\n" +
                                  $"Prochaine recave le {nextDate.Value:dd/MM/yyyy à HH:mm}";
                }
                else
                {
                    RebuyMessage = $"❌ Recaves non autorisées pour ce tournoi";
                }
            }
        }

        [RelayCommand]
        private async Task EliminatePlayerAsync()
        {
            if (SelectedEliminatedPlayer == null)
            {
                MessageBox.Show("Veuillez sélectionner un joueur à éliminer.", "Erreur", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // SÉCURITÉ: Vérifier qu'un joueur ne s'élimine pas lui-même
            if (SelectedKillerPlayer != null && SelectedKillerPlayer.Id == SelectedEliminatedPlayer.Id)
            {
                MessageBox.Show("Un joueur ne peut pas s'éliminer lui-même !", "Erreur", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var playerName = SelectedEliminatedPlayer.Player?.Name ?? "Joueur";
            var killerName = SelectedKillerPlayer?.Player?.Name ?? "inconnu";

            // Calculer la position AVANT l'élimination
            var activePlayers = await _tournamentService.GetActivePlayers(_tournamentId);
            var position = activePlayers.Count; // La position est le nombre de joueurs encore actifs

            var result = MessageBox.Show(
                $"Confirmer l'élimination de {playerName}" +
                (SelectedKillerPlayer != null ? $" par {killerName}" : "") +
                $"\n\nPosition finale : #{position}",
                "Confirmation",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    // Sauvegarder les infos du joueur AVANT l'élimination
                    var eliminatedPlayerId = SelectedEliminatedPlayer.PlayerId;
                    var eliminatedPlayerTournamentId = SelectedEliminatedPlayer.Id;

                    // Éliminer le joueur (le kill est compté ici)
                    await _tournamentService.EliminatePlayerAsync(
                        SelectedEliminatedPlayer.Id,
                        SelectedKillerPlayer?.Id);

                    // Ajouter à l'historique avec l'ID du killer pour pouvoir annuler
                    EliminationHistory.Insert(0, new EliminationHistoryItem
                    {
                        PlayerName = playerName,
                        PlayerId = SelectedEliminatedPlayer.Id,
                        KillerName = SelectedKillerPlayer != null ? killerName : "-",
                        KillerId = SelectedKillerPlayer?.Id,
                        Position = position,
                        Time = DateTime.Now
                    });

                    // Réinitialiser les sélections AVANT le refresh
                    SelectedEliminatedPlayer = null;
                    SelectedKillerPlayer = null;

                    await RefreshPlayersAsync();
                    await RefreshStatsAsync();

                    // Vérifier si le tournoi est terminé
                    if (PlayersRemaining == 1)
                    {
                        await HandleTournamentEndAsync();
                        return;
                    }

                    // NOUVEAU: Proposer la recave si autorisée
                    if (ShowRebuySection && await _playerService.CanPlayerRebuyAsync(eliminatedPlayerId, _tournamentId))
                    {
                        var rebuyResult = MessageBox.Show(
                            $"{playerName} souhaite-t-il recaver ?\n\n" +
                            $"Montant : {RebuyAmount:C}\n" +
                            $"Stack : {_tournament!.StartingStack:N0}",
                            "Proposition de recave",
                            MessageBoxButton.YesNo,
                            MessageBoxImage.Question);

                        if (rebuyResult == MessageBoxResult.Yes)
                        {
                            // Recharger le tournoi pour avoir les données à jour
                            _tournament = await _tournamentService.GetTournamentAsync(_tournamentId);
                            var playerToRebuy = _tournament?.Players.FirstOrDefault(p => p.Id == eliminatedPlayerTournamentId);
                            if (playerToRebuy != null)
                            {
                                await ProcessRebuyAsync(playerToRebuy, playerName);
                            }
                        }
                        else
                        {
                            MessageBox.Show($"{playerName} éliminé(e) en position #{position}.", "Élimination confirmée", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show($"{playerName} éliminé(e) en position #{position}.", "Élimination confirmée", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erreur lors de l'élimination : {ex.Message}", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        /// <summary>
        /// Traite la recave d'un joueur (utilisé après élimination ou manuellement)
        /// </summary>
        private async Task ProcessRebuyAsync(TournamentPlayer player, string playerName)
        {
            if (_tournament == null) return;

            try
            {
                // Enregistrer la recave
                await _playerService.RecordRebuyAsync(
                    player.PlayerId,
                    _tournamentId,
                    RebuyAmount);

                // Réactiver le joueur avec le starting stack
                player.IsEliminated = false;
                player.CurrentStack = _tournament.StartingStack;
                player.RebuyCount++;
                player.FinishPosition = null;
                player.EliminationTime = null;
                // NOTE: On garde EliminatedByPlayerId null mais le kill reste compté !

                await _tournamentService.UpdateTournamentPlayerAsync(player);

                // Mettre à jour le total des rebuys du tournoi
                _tournament.TotalRebuys++;
                await _tournamentService.UpdateTournamentAsync(_tournament);

                // Retirer de l'historique d'élimination
                var historyItem = EliminationHistory.FirstOrDefault(h => h.PlayerId == player.Id);
                if (historyItem != null)
                {
                    EliminationHistory.Remove(historyItem);
                }

                await RefreshPlayersAsync();
                await RefreshStatsAsync();

                System.Media.SystemSounds.Asterisk.Play();
                MessageBox.Show($"✅ {playerName} a recavé !\n\nNouveau stack : {_tournament.StartingStack:N0}\nPrize Pool : {CurrentPrizePool:C}", "Recave effectuée", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la recave : {ex.Message}", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task HandleTournamentEndAsync()
        {
            if (_tournament == null) return;

            IsTournamentFinished = true;

            // Trouver le gagnant
            var winner = ActivePlayers.FirstOrDefault();
            if (winner != null)
            {
                WinnerName = winner.Player?.Name ?? "Inconnu";

                // Mettre à jour le gagnant
                winner.FinishPosition = 1;
                winner.Winnings = CurrentPrizePool;
                await _tournamentService.UpdateTournamentPlayerAsync(winner);

                // Mettre à jour le tournoi
                _tournament.Status = TournamentStatus.Finished;
                _tournament.EndTime = DateTime.Now;
                await _tournamentService.UpdateTournamentAsync(_tournament);

                // Notifier
                TournamentFinished?.Invoke(this, WinnerName);

                MessageBox.Show(
                    $"🏆 TOURNOI TERMINÉ ! 🏆\n\n" +
                    $"Vainqueur : {WinnerName}\n" +
                    $"Prize Pool : {CurrentPrizePool:C}",
                    "Fin du Tournoi",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
        }

        [RelayCommand]
        private async Task RebuyPlayerAsync()
        {
            if (SelectedEliminatedPlayer == null || _tournament == null) return;

            if (!CanRebuy)
            {
                MessageBox.Show(RebuyMessage, "Recave impossible", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var playerName = SelectedEliminatedPlayer.Player?.Name ?? "Joueur";

            var result = MessageBox.Show(
                $"Confirmer la recave de {playerName} ?\n\n" +
                $"Montant : {RebuyAmount:C}\n" +
                $"Recave n°{RebuyCount + 1}",
                "Confirmation Recave",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                await ProcessRebuyAsync(SelectedEliminatedPlayer, playerName);
                SelectedEliminatedPlayer = null;
                SelectedKillerPlayer = null;
            }
        }

        [RelayCommand]
        private void ClearSelection()
        {
            SelectedEliminatedPlayer = null;
            SelectedKillerPlayer = null;
            CanRebuy = false;
            RebuyMessage = string.Empty;
        }

        [RelayCommand]
        private async Task UndoLastEliminationAsync()
        {
            if (!EliminationHistory.Any())
            {
                MessageBox.Show("Aucune élimination à annuler.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var lastElimination = EliminationHistory.First();

            var result = MessageBox.Show(
                $"Annuler l'élimination de {lastElimination.PlayerName} ?" +
                (lastElimination.KillerId.HasValue ? $"\n\nLe kill de {lastElimination.KillerName} sera également retiré." : ""),
                "Confirmation",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                // Trouver le joueur éliminé
                var player = _tournament?.Players.FirstOrDefault(p =>
                    p.Id == lastElimination.PlayerId &&
                    p.IsEliminated);

                if (player != null)
                {
                    // Réactiver le joueur
                    player.IsEliminated = false;
                    player.FinishPosition = null;
                    player.EliminationTime = null;
                    player.EliminatedByPlayerId = null;

                    await _tournamentService.UpdateTournamentPlayerAsync(player);

                    // IMPORTANT: Retirer le kill au killer
                    if (lastElimination.KillerId.HasValue)
                    {
                        var killer = _tournament?.Players.FirstOrDefault(p => p.Id == lastElimination.KillerId.Value);
                        if (killer != null && killer.BountyKills > 0)
                        {
                            killer.BountyKills--;
                            await _tournamentService.UpdateTournamentPlayerAsync(killer);
                        }
                    }

                    EliminationHistory.Remove(lastElimination);

                    await RefreshPlayersAsync();
                    await RefreshStatsAsync();

                    MessageBox.Show("Élimination annulée.", "Succès", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Impossible de trouver le joueur éliminé.", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }

    // Classe helper pour l'historique - améliorée avec les IDs
    public class EliminationHistoryItem
    {
        public string PlayerName { get; set; } = string.Empty;
        public int PlayerId { get; set; }
        public string KillerName { get; set; } = string.Empty;
        public int? KillerId { get; set; }
        public int Position { get; set; }
        public DateTime Time { get; set; }
        public string TimeFormatted => Time.ToString("HH:mm:ss");
    }
}
