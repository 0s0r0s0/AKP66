using PokerTournamentDirector.ViewModels;
using System;
using System.Windows;

namespace PokerTournamentDirector.Views
{
    public partial class TournamentSetupView : Window
    {
        private readonly TournamentSetupViewModel _viewModel;
        private readonly IServiceProvider _serviceProvider;

        public int? CreatedTournamentId { get; private set; }
        public bool TournamentStarted { get; private set; }

        public TournamentSetupView(TournamentSetupViewModel viewModel, IServiceProvider serviceProvider)
        {
            InitializeComponent();
            _viewModel = viewModel;
            _serviceProvider = serviceProvider;
            DataContext = _viewModel;

            // S'abonner à l'événement de démarrage
            _viewModel.TournamentReadyToStart += OnTournamentReadyToStart;

            // Initialiser les données
            Loaded += async (s, e) => await _viewModel.InitializeAsync();
        }

        private void OnTournamentReadyToStart(object? sender, int tournamentId)
        {
            CreatedTournamentId = tournamentId;
            TournamentStarted = true;
            DialogResult = true;
            Close();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            if (_viewModel.TournamentId.HasValue && _viewModel.CurrentStep > 1)
            {
                var result = MessageBox.Show(
                    "Un tournoi est en cours de création.\n\nVoulez-vous l'annuler ?",
                    "Confirmation",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (result == MessageBoxResult.No)
                    return;

                // Annuler le tournoi
                _viewModel.CancelTournamentCommand.Execute(null);
            }

            DialogResult = false;
            Close();
        }

        protected override void OnClosed(EventArgs e)
        {
            _viewModel.TournamentReadyToStart -= OnTournamentReadyToStart;
            base.OnClosed(e);
        }
    }
}
