using System;
using System.IO;
using System.Windows.Media;

namespace PokerTournamentDirector.Services
{
    /// <summary>
    /// Service pour jouer les sons MP3 personnalisés du tournoi
    /// </summary>
    public class AudioService
    {
        private readonly MediaPlayer _mediaPlayer;
        private readonly string _soundsFolder;
        private bool _isInitialized;

        // Noms des fichiers sons
        public const string SOUND_START = "start.mp3";
        public const string SOUND_PAUSE = "pause.mp3";
        public const string SOUND_60S = "60s.mp3";
        public const string SOUND_COUNTDOWN = "countdown.mp3";
        public const string SOUND_LEVEL = "level.mp3";

        public AudioService()
        {
            _mediaPlayer = new MediaPlayer();
            
            // Dossier des sons dans AppData
            _soundsFolder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "PokerTournamentDirector",
                "Sounds");

            EnsureSoundsFolderExists();
        }

        private void EnsureSoundsFolderExists()
        {
            try
            {
                if (!Directory.Exists(_soundsFolder))
                {
                    Directory.CreateDirectory(_soundsFolder);
                }
                _isInitialized = true;
            }
            catch
            {
                _isInitialized = false;
            }
        }

        /// <summary>
        /// Joue un son si le fichier existe
        /// </summary>
        public void PlaySound(string soundFileName)
        {
            if (!_isInitialized) return;

            try
            {
                var soundPath = Path.Combine(_soundsFolder, soundFileName);
                
                if (File.Exists(soundPath))
                {
                    _mediaPlayer.Stop();
                    _mediaPlayer.Open(new Uri(soundPath));
                    _mediaPlayer.Play();
                }
                else
                {
                    // Fallback sur les sons système si le MP3 n'existe pas
                    PlayFallbackSound(soundFileName);
                }
            }
            catch
            {
                // En cas d'erreur, utiliser le son système
                PlayFallbackSound(soundFileName);
            }
        }

        private void PlayFallbackSound(string soundFileName)
        {
            switch (soundFileName)
            {
                case SOUND_START:
                case SOUND_LEVEL:
                    System.Media.SystemSounds.Asterisk.Play();
                    break;
                case SOUND_PAUSE:
                    System.Media.SystemSounds.Hand.Play();
                    break;
                case SOUND_60S:
                    System.Media.SystemSounds.Beep.Play();
                    break;
                case SOUND_COUNTDOWN:
                    System.Media.SystemSounds.Exclamation.Play();
                    break;
                default:
                    System.Media.SystemSounds.Beep.Play();
                    break;
            }
        }

        /// <summary>
        /// Vérifie si un son personnalisé existe
        /// </summary>
        public bool SoundExists(string soundFileName)
        {
            if (!_isInitialized) return false;
            var soundPath = Path.Combine(_soundsFolder, soundFileName);
            return File.Exists(soundPath);
        }

        /// <summary>
        /// Retourne le chemin du dossier des sons
        /// </summary>
        public string GetSoundsFolderPath() => _soundsFolder;

        /// <summary>
        /// Liste les sons disponibles
        /// </summary>
        public string[] GetAvailableSounds()
        {
            if (!_isInitialized || !Directory.Exists(_soundsFolder))
                return Array.Empty<string>();

            return Directory.GetFiles(_soundsFolder, "*.mp3");
        }

        /// <summary>
        /// Arrête le son en cours
        /// </summary>
        public void Stop()
        {
            _mediaPlayer.Stop();
        }

        /// <summary>
        /// Définit le volume (0.0 à 1.0)
        /// </summary>
        public void SetVolume(double volume)
        {
            _mediaPlayer.Volume = Math.Clamp(volume, 0.0, 1.0);
        }
    }
}
