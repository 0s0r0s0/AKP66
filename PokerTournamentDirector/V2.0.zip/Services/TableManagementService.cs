using Microsoft.EntityFrameworkCore;
using PokerTournamentDirector.Data;
using PokerTournamentDirector.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PokerTournamentDirector.Services
{
    /// <summary>
    /// Service pour la gestion des tables et le placement des joueurs
    /// </summary>
    public class TableManagementService
    {
        private readonly PokerDbContext _context;

        public TableManagementService(PokerDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Crée les tables nécessaires pour un tournoi
        /// </summary>
        public async Task<List<PokerTable>> CreateTablesAsync(int tournamentId)
        {
            var tournament = await _context.Tournaments
                .Include(t => t.Players)
                .Include(t => t.Tables)
                .FirstOrDefaultAsync(t => t.Id == tournamentId);

            if (tournament == null) return new List<PokerTable>();

            var activePlayers = tournament.Players.Where(p => !p.IsEliminated).ToList();
            int playerCount = activePlayers.Count;
            int seatsPerTable = tournament.SeatsPerTable;

            // Calculer le nombre de tables nécessaires
            int tableCount = (int)Math.Ceiling((double)playerCount / seatsPerTable);
            if (tableCount == 0) tableCount = 1;

            // Supprimer les anciennes tables
            if (tournament.Tables.Any())
            {
                _context.PokerTables.RemoveRange(tournament.Tables);
                await _context.SaveChangesAsync();
            }

            // Créer les nouvelles tables
            var tables = new List<PokerTable>();
            for (int i = 1; i <= tableCount; i++)
            {
                var table = new PokerTable
                {
                    TournamentId = tournamentId,
                    TableNumber = i,
                    MaxSeats = seatsPerTable,
                    IsActive = true
                };
                tables.Add(table);
                _context.PokerTables.Add(table);
            }

            await _context.SaveChangesAsync();
            return tables;
        }

        /// <summary>
        /// Place automatiquement tous les joueurs aux tables de manière équilibrée
        /// </summary>
        public async Task<List<TableSeatAssignment>> AutoAssignPlayersAsync(int tournamentId)
        {
            var tournament = await _context.Tournaments
                .Include(t => t.Players).ThenInclude(tp => tp.Player)
                .Include(t => t.Tables)
                .FirstOrDefaultAsync(t => t.Id == tournamentId);

            if (tournament == null) return new List<TableSeatAssignment>();

            var tables = tournament.Tables.Where(t => t.IsActive).OrderBy(t => t.TableNumber).ToList();
            var players = tournament.Players.Where(p => !p.IsEliminated && !p.IsLocked).OrderBy(_ => Guid.NewGuid()).ToList();
            var lockedPlayers = tournament.Players.Where(p => !p.IsEliminated && p.IsLocked).ToList();

            if (!tables.Any()) return new List<TableSeatAssignment>();

            var assignments = new List<TableSeatAssignment>();
            var seatCountPerTable = new Dictionary<int, int>();

            foreach (var table in tables)
            {
                seatCountPerTable[table.Id] = 0;
            }

            // D'abord, placer les joueurs verrouillés
            foreach (var player in lockedPlayers)
            {
                if (player.TableId.HasValue && player.SeatNumber.HasValue)
                {
                    var existingTable = tables.FirstOrDefault(t => t.Id == player.TableId);
                    if (existingTable != null)
                    {
                        seatCountPerTable[existingTable.Id]++;
                        assignments.Add(new TableSeatAssignment
                        {
                            TournamentPlayerId = player.Id,
                            PlayerName = player.Player?.Name ?? "?",
                            TableId = existingTable.Id,
                            TableNumber = existingTable.TableNumber,
                            SeatNumber = player.SeatNumber.Value,
                            IsLocked = true
                        });
                    }
                }
            }

            // Ensuite, placer les autres joueurs de manière équilibrée
            foreach (var player in players)
            {
                // Trouver la table avec le moins de joueurs
                var targetTable = tables
                    .Where(t => seatCountPerTable[t.Id] < t.MaxSeats)
                    .OrderBy(t => seatCountPerTable[t.Id])
                    .ThenBy(t => t.TableNumber)
                    .FirstOrDefault();

                if (targetTable == null) continue;

                // Trouver le prochain siège disponible
                var occupiedSeats = assignments
                    .Where(a => a.TableId == targetTable.Id)
                    .Select(a => a.SeatNumber)
                    .ToHashSet();

                int nextSeat = 1;
                while (occupiedSeats.Contains(nextSeat) && nextSeat <= targetTable.MaxSeats)
                {
                    nextSeat++;
                }

                player.TableId = targetTable.Id;
                player.SeatNumber = nextSeat;
                seatCountPerTable[targetTable.Id]++;

                assignments.Add(new TableSeatAssignment
                {
                    TournamentPlayerId = player.Id,
                    PlayerName = player.Player?.Name ?? "?",
                    TableId = targetTable.Id,
                    TableNumber = targetTable.TableNumber,
                    SeatNumber = nextSeat,
                    IsLocked = false
                });
            }

            await _context.SaveChangesAsync();
            return assignments.OrderBy(a => a.TableNumber).ThenBy(a => a.SeatNumber).ToList();
        }

        /// <summary>
        /// Déplace un joueur vers une table/siège spécifique
        /// </summary>
        public async Task<bool> MovePlayerAsync(int tournamentPlayerId, int targetTableId, int targetSeat)
        {
            var player = await _context.TournamentPlayers.FindAsync(tournamentPlayerId);
            if (player == null) return false;

            var table = await _context.PokerTables.FindAsync(targetTableId);
            if (table == null) return false;

            // Vérifier si le siège est libre
            var existingPlayer = await _context.TournamentPlayers
                .FirstOrDefaultAsync(p => p.TableId == targetTableId && p.SeatNumber == targetSeat && p.Id != tournamentPlayerId);

            if (existingPlayer != null)
            {
                // Échanger les places
                existingPlayer.TableId = player.TableId;
                existingPlayer.SeatNumber = player.SeatNumber;
            }

            player.TableId = targetTableId;
            player.SeatNumber = targetSeat;

            await _context.SaveChangesAsync();
            return true;
        }

        /// <summary>
        /// Verrouille/déverrouille un joueur à sa place
        /// </summary>
        public async Task<bool> ToggleLockPlayerAsync(int tournamentPlayerId)
        {
            var player = await _context.TournamentPlayers.FindAsync(tournamentPlayerId);
            if (player == null) return false;

            player.IsLocked = !player.IsLocked;
            await _context.SaveChangesAsync();
            return player.IsLocked;
        }

        /// <summary>
        /// Équilibre les tables après une élimination
        /// </summary>
        public async Task<BalanceResult> BalanceTablesAsync(int tournamentId)
        {
            var tournament = await _context.Tournaments
                .Include(t => t.Players).ThenInclude(tp => tp.Player)
                .Include(t => t.Tables)
                .FirstOrDefaultAsync(t => t.Id == tournamentId);

            if (tournament == null)
                return new BalanceResult { Success = false, Message = "Tournoi introuvable" };

            var activePlayers = tournament.Players.Where(p => !p.IsEliminated).ToList();
            var activeTables = tournament.Tables.Where(t => t.IsActive).OrderBy(t => t.TableNumber).ToList();

            if (!activeTables.Any() || !activePlayers.Any())
                return new BalanceResult { Success = true, Message = "Rien à équilibrer" };

            int playerCount = activePlayers.Count;
            int seatsPerTable = tournament.SeatsPerTable;

            // Calculer le nombre optimal de tables
            int optimalTableCount = (int)Math.Ceiling((double)playerCount / seatsPerTable);

            // Si on peut réduire à une seule table, le faire si possible
            if (playerCount <= seatsPerTable && activeTables.Count > 1)
            {
                return await ConsolidateToOneTableAsync(tournament, activePlayers, activeTables);
            }

            // Vérifier si on doit casser une table
            if (activeTables.Count > optimalTableCount)
            {
                return await BreakTableAsync(tournament, activePlayers, activeTables);
            }

            // Équilibrer les joueurs entre les tables existantes
            return await EqualizeTables(tournament, activePlayers, activeTables);
        }

        private async Task<BalanceResult> ConsolidateToOneTableAsync(
            Tournament tournament,
            List<TournamentPlayer> activePlayers,
            List<PokerTable> activeTables)
        {
            // Garder la table 1 (priorité)
            var mainTable = activeTables.OrderBy(t => t.TableNumber).First();
            var otherTables = activeTables.Where(t => t.Id != mainTable.Id).ToList();

            var movements = new List<PlayerMovement>();
            int seatNumber = 1;

            // Récupérer les sièges déjà occupés sur la table principale
            var occupiedSeats = activePlayers
                .Where(p => p.TableId == mainTable.Id)
                .Select(p => p.SeatNumber ?? 0)
                .ToHashSet();

            foreach (var player in activePlayers.Where(p => p.TableId != mainTable.Id))
            {
                // Trouver le prochain siège libre
                while (occupiedSeats.Contains(seatNumber) && seatNumber <= mainTable.MaxSeats)
                {
                    seatNumber++;
                }

                movements.Add(new PlayerMovement
                {
                    PlayerName = player.Player?.Name ?? "?",
                    FromTable = activeTables.FirstOrDefault(t => t.Id == player.TableId)?.TableNumber ?? 0,
                    FromSeat = player.SeatNumber ?? 0,
                    ToTable = mainTable.TableNumber,
                    ToSeat = seatNumber
                });

                player.TableId = mainTable.Id;
                player.SeatNumber = seatNumber;
                occupiedSeats.Add(seatNumber);
                seatNumber++;
            }

            // Désactiver les autres tables
            foreach (var table in otherTables)
            {
                table.IsActive = false;
            }

            await _context.SaveChangesAsync();

            return new BalanceResult
            {
                Success = true,
                TableBroken = true,
                BrokenTableNumber = otherTables.FirstOrDefault()?.TableNumber ?? 0,
                Movements = movements,
                Message = $"Table {otherTables.FirstOrDefault()?.TableNumber} cassée. {movements.Count} joueur(s) déplacé(s) vers la Table {mainTable.TableNumber}."
            };
        }

        private async Task<BalanceResult> BreakTableAsync(
            Tournament tournament,
            List<TournamentPlayer> activePlayers,
            List<PokerTable> activeTables)
        {
            // Casser la table avec le moins de joueurs (mais pas la table 1 si possible)
            var tablePlayerCounts = activeTables
                .Select(t => new
                {
                    Table = t,
                    Count = activePlayers.Count(p => p.TableId == t.Id)
                })
                .OrderBy(x => x.Count)
                .ThenByDescending(x => x.Table.TableNumber) // Préférer casser les tables avec numéro élevé
                .ToList();

            var tableToBreak = tablePlayerCounts.First().Table;
            var playersToMove = activePlayers.Where(p => p.TableId == tableToBreak.Id && !p.IsLocked).ToList();
            var remainingTables = activeTables.Where(t => t.Id != tableToBreak.Id).OrderBy(t => t.TableNumber).ToList();

            var movements = new List<PlayerMovement>();

            foreach (var player in playersToMove)
            {
                // Trouver la table avec le moins de joueurs
                var targetTable = remainingTables
                    .Select(t => new { Table = t, Count = activePlayers.Count(p => p.TableId == t.Id) })
                    .OrderBy(x => x.Count)
                    .First().Table;

                // Trouver un siège libre
                var occupiedSeats = activePlayers
                    .Where(p => p.TableId == targetTable.Id)
                    .Select(p => p.SeatNumber ?? 0)
                    .ToHashSet();

                int seatNumber = 1;
                while (occupiedSeats.Contains(seatNumber) && seatNumber <= targetTable.MaxSeats)
                {
                    seatNumber++;
                }

                movements.Add(new PlayerMovement
                {
                    PlayerName = player.Player?.Name ?? "?",
                    FromTable = tableToBreak.TableNumber,
                    FromSeat = player.SeatNumber ?? 0,
                    ToTable = targetTable.TableNumber,
                    ToSeat = seatNumber
                });

                player.TableId = targetTable.Id;
                player.SeatNumber = seatNumber;
            }

            tableToBreak.IsActive = false;
            await _context.SaveChangesAsync();

            return new BalanceResult
            {
                Success = true,
                TableBroken = true,
                BrokenTableNumber = tableToBreak.TableNumber,
                Movements = movements,
                Message = $"Table {tableToBreak.TableNumber} cassée ! {movements.Count} joueur(s) réparti(s)."
            };
        }

        private async Task<BalanceResult> EqualizeTables(
            Tournament tournament,
            List<TournamentPlayer> activePlayers,
            List<PokerTable> activeTables)
        {
            var movements = new List<PlayerMovement>();

            // Calculer le nombre idéal de joueurs par table
            int totalPlayers = activePlayers.Count;
            int tableCount = activeTables.Count;
            int basePlayersPerTable = totalPlayers / tableCount;
            int extraPlayers = totalPlayers % tableCount;

            // Compter les joueurs par table
            var tableCounts = activeTables
                .Select(t => new
                {
                    Table = t,
                    Count = activePlayers.Count(p => p.TableId == t.Id),
                    Target = basePlayersPerTable + (t.TableNumber <= extraPlayers ? 1 : 0)
                })
                .ToList();

            // Identifier les tables avec trop ou pas assez de joueurs
            var tablesWithExcess = tableCounts.Where(t => t.Count > t.Target + 1).ToList();
            var tablesNeedingPlayers = tableCounts.Where(t => t.Count < t.Target - 1).OrderBy(t => t.Count).ToList();

            // Déplacer les joueurs des tables surchargées vers les tables en sous-effectif
            foreach (var excess in tablesWithExcess)
            {
                var playersToMove = activePlayers
                    .Where(p => p.TableId == excess.Table.Id && !p.IsLocked)
                    .Take(excess.Count - excess.Target)
                    .ToList();

                foreach (var player in playersToMove)
                {
                    var targetTableInfo = tablesNeedingPlayers.FirstOrDefault();
                    if (targetTableInfo == null) break;

                    var targetTable = targetTableInfo.Table;

                    // Trouver un siège libre
                    var occupiedSeats = activePlayers
                        .Where(p => p.TableId == targetTable.Id)
                        .Select(p => p.SeatNumber ?? 0)
                        .ToHashSet();

                    int seatNumber = 1;
                    while (occupiedSeats.Contains(seatNumber) && seatNumber <= targetTable.MaxSeats)
                    {
                        seatNumber++;
                    }

                    movements.Add(new PlayerMovement
                    {
                        PlayerName = player.Player?.Name ?? "?",
                        FromTable = excess.Table.TableNumber,
                        FromSeat = player.SeatNumber ?? 0,
                        ToTable = targetTable.TableNumber,
                        ToSeat = seatNumber
                    });

                    player.TableId = targetTable.Id;
                    player.SeatNumber = seatNumber;
                }
            }

            if (movements.Any())
            {
                await _context.SaveChangesAsync();
            }

            return new BalanceResult
            {
                Success = true,
                TableBroken = false,
                Movements = movements,
                Message = movements.Any()
                    ? $"Équilibrage effectué : {movements.Count} joueur(s) déplacé(s)."
                    : "Tables déjà équilibrées."
            };
        }

        /// <summary>
        /// Ajoute un joueur retardataire à la table la plus appropriée
        /// </summary>
        public async Task<TableSeatAssignment?> AssignLatePlayerAsync(int tournamentPlayerId)
        {
            var player = await _context.TournamentPlayers
                .Include(p => p.Player)
                .FirstOrDefaultAsync(p => p.Id == tournamentPlayerId);

            if (player == null) return null;

            var tables = await _context.PokerTables
                .Where(t => t.TournamentId == player.TournamentId && t.IsActive)
                .ToListAsync();

            if (!tables.Any()) return null;

            // Compter les joueurs par table
            var playerCounts = await _context.TournamentPlayers
                .Where(p => p.TournamentId == player.TournamentId && !p.IsEliminated && p.TableId != null)
                .GroupBy(p => p.TableId)
                .Select(g => new { TableId = g.Key, Count = g.Count() })
                .ToDictionaryAsync(x => x.TableId ?? 0, x => x.Count);

            // Trouver la table avec le moins de joueurs
            var targetTable = tables
                .OrderBy(t => playerCounts.GetValueOrDefault(t.Id, 0))
                .ThenBy(t => t.TableNumber)
                .First();

            // Trouver un siège libre
            var occupiedSeats = await _context.TournamentPlayers
                .Where(p => p.TableId == targetTable.Id && !p.IsEliminated)
                .Select(p => p.SeatNumber ?? 0)
                .ToListAsync();

            int seatNumber = 1;
            while (occupiedSeats.Contains(seatNumber) && seatNumber <= targetTable.MaxSeats)
            {
                seatNumber++;
            }

            player.TableId = targetTable.Id;
            player.SeatNumber = seatNumber;
            await _context.SaveChangesAsync();

            return new TableSeatAssignment
            {
                TournamentPlayerId = player.Id,
                PlayerName = player.Player?.Name ?? "?",
                TableId = targetTable.Id,
                TableNumber = targetTable.TableNumber,
                SeatNumber = seatNumber,
                IsLocked = false
            };
        }

        /// <summary>
        /// Obtient le plan actuel des tables
        /// </summary>
        public async Task<List<TableLayout>> GetTableLayoutAsync(int tournamentId)
        {
            var tournament = await _context.Tournaments
                .Include(t => t.Players).ThenInclude(tp => tp.Player)
                .Include(t => t.Tables)
                .FirstOrDefaultAsync(t => t.Id == tournamentId);

            if (tournament == null) return new List<TableLayout>();

            var layouts = new List<TableLayout>();

            foreach (var table in tournament.Tables.Where(t => t.IsActive).OrderBy(t => t.TableNumber))
            {
                var layout = new TableLayout
                {
                    TableId = table.Id,
                    TableNumber = table.TableNumber,
                    MaxSeats = table.MaxSeats,
                    Seats = new List<SeatInfo>()
                };

                var playersAtTable = tournament.Players
                    .Where(p => p.TableId == table.Id && !p.IsEliminated)
                    .OrderBy(p => p.SeatNumber)
                    .ToList();

                for (int seat = 1; seat <= table.MaxSeats; seat++)
                {
                    var playerAtSeat = playersAtTable.FirstOrDefault(p => p.SeatNumber == seat);
                    layout.Seats.Add(new SeatInfo
                    {
                        SeatNumber = seat,
                        IsOccupied = playerAtSeat != null,
                        TournamentPlayerId = playerAtSeat?.Id,
                        PlayerName = playerAtSeat?.Player?.Name,
                        IsLocked = playerAtSeat?.IsLocked ?? false,
                        CurrentStack = playerAtSeat?.CurrentStack ?? 0
                    });
                }

                layout.PlayerCount = playersAtTable.Count;
                layouts.Add(layout);
            }

            return layouts;
        }
    }

    // Classes helper
    public class TableSeatAssignment
    {
        public int TournamentPlayerId { get; set; }
        public string PlayerName { get; set; } = string.Empty;
        public int TableId { get; set; }
        public int TableNumber { get; set; }
        public int SeatNumber { get; set; }
        public bool IsLocked { get; set; }
    }

    public class BalanceResult
    {
        public bool Success { get; set; }
        public bool TableBroken { get; set; }
        public int BrokenTableNumber { get; set; }
        public List<PlayerMovement> Movements { get; set; } = new();
        public string Message { get; set; } = string.Empty;
    }

    public class PlayerMovement
    {
        public string PlayerName { get; set; } = string.Empty;
        public int FromTable { get; set; }
        public int FromSeat { get; set; }
        public int ToTable { get; set; }
        public int ToSeat { get; set; }
    }

    public class TableLayout
    {
        public int TableId { get; set; }
        public int TableNumber { get; set; }
        public int MaxSeats { get; set; }
        public int PlayerCount { get; set; }
        public List<SeatInfo> Seats { get; set; } = new();
    }

    public class SeatInfo
    {
        public int SeatNumber { get; set; }
        public bool IsOccupied { get; set; }
        public int? TournamentPlayerId { get; set; }
        public string? PlayerName { get; set; }
        public bool IsLocked { get; set; }
        public int CurrentStack { get; set; }
    }
}